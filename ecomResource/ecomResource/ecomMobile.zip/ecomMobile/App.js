import React from 'react';
import Providers from './navigation';

const App = () => {
  return <Providers />;
}

export default App;